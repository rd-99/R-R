const formReducer = (state , action) => {
    switch(action.type){
        case "HANDLE_INPUT_TEXT" :
            console.log(state , action.field , action.payload);
            return {
                ...state , [action.field] : action.payload,
            };
        // case "teamMembers" :
        //     return {
        //         ...state , teamMembers : action.payload,
        //     };
        // case "nominationCategory" :
        //     return {
        //         ...state , nominationCategory : action.payload,
        //     };
        // case "description" :
        //     return {
        //         ...state , description : action.payload,
        //     };
        // case "domain" :
        //     return {
        //         ...state , domain : action.payload,
        //     };
        // case "improvementCategory" :
        //     return {
        //         ...state , improvementCategory : action.payload,
        //     };
        // case "complexity" :
        //     return {
        //         ...state , complexity : action.payload,
        //     };
        default : 
        return state
    }
}

export default formReducer ;