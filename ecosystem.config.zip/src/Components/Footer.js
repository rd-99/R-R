import React from 'react'
import img3 from '../public/images/iqvia-logo_color.svg'
import 'bootstrap/dist/css/bootstrap.min.css'
const Footer = () => {
  return (
    <div>
      {/* <footer className="page-footer">
        <div className="container">
          <div className="row justify-content-center mb-1">
            <div className="col-lg-3">
              <h3><img src={img3} /></h3>
              <p id="copyright">&copy; 2023 <a href="https://iqvia.com">IQVIA</a>.</p>
            </div>
            <div className="col-lg-3">
            </div>
            <div className="col-lg-3">
            </div>
            <div className="col-lg-3">
              <h5>RDS IT - Rewards and Recognitions</h5>
            </div>
          </div>
        </div>
      </footer> */}
    </div>
  )
}

export default Footer
