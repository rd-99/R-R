import React from "react"
import ReactToPrint from "react-to-print"
import * as Icon from 'react-bootstrap-icons'
import Header from "../Header"
import img1 from '../../public/images/iqvia-logo_color.svg'
import img2 from '../../public/images/sign.jpg'
import prize from '../../public/images/prize2.jfif'
//const images = require.context('../../../../be/profileImages', true)

class ExportPdfComponent extends React.Component {
    constructor(props) {
        super(props)
        this.details = this.props.x
    }

    render() {
        return (
            <div>
                <Header />
                <div className="row container" style={{minWidth: "-webkit-fill-available",
                                                        overflowX: "auto"}}>
                    {/* <div className="text-center certificate" ref={(response) => (this.componentRef = response)} >
                            <div style={{position:"relative",left:"10mm", top:"10mm",bottom:"10mm", width:"245mm", border:"1mm solid #0f1a5c", 
                            backgroundImage:"url(https://th.bing.com/th/id/R.5874df9522dcee6c7fb795a5b477e749?rik=EYFC%2bB7uyXCk7Q&riu=http%3a%2f%2fwww.freepptbackgrounds.net%2fwp-content%2fuploads%2f2014%2f04%2fLight-Blue-Lines-Theme.jpg&ehk=dr%2fLEvY2DEsH6LCghNeGa597F1H5li6Tmdtq1AlJPew%3d&risl=&pid=ImgRaw&r=0)",}}>
                                <div style={{border:"1mm solid #0f1a5c",margin:"3vh", textAlign:"center"}}>
                                    <div className="row">
                                        <img src={img2} className="badge-img"/>
                                        <div className="col col-md-6 text-center logo m-5">
                                            <h4>IQVIA RDS IT</h4>
                                            <p> presents</p>
                                        </div>
                                        <div className="col mt-5">
                                            <img src={img1} />
                                        </div>
                                        <h1 className="col col-md-9 marquee mx-auto" >Certificate Of Appreciation</h1>

                                    </div>
                                    <h5 className="assignment mt-5">Under Rewards & Recognitions</h5>
                                    <div className="assignment">This certificate is proudly presented to</div>
                                    
                                    <div className="person">{this.props.x.nomineeName}</div>
                                    <div className="reason">
                                        For their contribution in
                                        <br />
                                    </div>
                                    <p> <i className="mt-3 certificate-category">{this.props.x.nominationCategory}</i></p>
                                    <p className="reason m-5">Issued On {new Date(this.props.x.updatedOn).toDateString()}
                                    </p>
                                </div>
                            </div>
                        </div> */}
                    <div className='col container'>
                        <div className="pm-certificate-container" ref={(response) => (this.componentRef = response)}>
                            <div className="outer-border"></div>
                            <div className="inner-border"></div>
                            <div className="pm-certificate-border col-xs-12">
                                <div className="row pm-certificate-header">
                                 <Icon.BookmarkFill size={90} className="col-2" style={{color:"#618597", marginTop:"-10px"}}/>
                                    <img src={img1} className='w-25 h-25 badge-img mt-4' />
                                    <div className="pm-certificate-title cursive col-xs-12 text-center">
                                        <h2>{this.props.x.nominationCategory}</h2>
                                    </div>
                                </div>

                                <div className="row pm-certificate-body">

                                    <div className="col-xs-12">
                                        <div className="row">
                                            <div className="pm-earned col-xs-8 text-center">
                                                <span className="pm-earned-text padding-0 cursive">Awarded to</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xs-12">
                                        <div className="row" >
                                            <div className="h-25 col-xs-8 text-center">
                                                <img src={prize} className='icon-img' />

                                            </div>
                                        </div>
                                    </div>
                                    <div className="pm-certificate-block">
                                        <div className="col-xs-12">
                                            <div className="row">
                                                <div className="col-xs-2"> </div>
                                                <div className="pm-certificate-name underline margin-0 col-xs-8 text-center">
                                                    <span className="pm-name-text bold">{this.props.x.nomineeName}</span>
                                                </div>
                                                <div className="col-xs-2"> </div>
                                            </div>
                                        </div>

                                        <div className="col-xs-12">
                                            <div className="row">
                                                <div className="pm-earned col-xs-8 text-center">
                                                    <span className="pm-earned-text padding-0 block cursive">for</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12">
                                            <div className="row">
                                                <div className="col-xs-2"> </div>
                                                <div className="pm-course-title underline col-xs-8 text-center">
                                                    <span className="pm-credits-text block bold sans">
                                                    {this.props.x.certificateCitation} </span>
                                                </div>
                                                <div className="col-xs-2"> </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-xs-12">
                                        <div className="pm-certificate-footer row">
                                            <div className="col col-lg-4 pm-certified col-xs-4 text-center">
                                                <span className="pm-credits-text block sans">
                                                    <img src={img2} className="w-50 h-50" />
                                                </span>
                                                <hr />
                                                <span className="bold block">Nivedita Jain, Sr Director, RDS IT</span>
                                            </div>
                                            <div className="col col-lg-4">

                                            </div>
                                            <div className="col col-lg-4 pm-certified col-xs-4 text-center">
                                                {/* date of townhall */}
                                                <span className="pm-credits-text block sans">{new Date(this.props.x.createdOn).toDateString()}</span>
                                                <hr />
                                                <span className="bold block">Date: </span>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <ReactToPrint
                        content={() => this.componentRef}
                        trigger={() => (
                            <button className="btn btn-success col h-25 m-4">Print to PDF!</button>
                        )}
                    />
                </div>
            </div>
        )
    }
}

export default ExportPdfComponent
