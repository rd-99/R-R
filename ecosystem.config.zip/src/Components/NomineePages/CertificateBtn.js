import React, { useEffect, useState } from 'react'
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css'
import "../../App.css"
import axios from 'axios';
import { CONFIG } from '../../config';

const CertificateBtn = ({ uuid }) => {
    const [citation, setCitation] = useState('')
    useEffect(() => {
        let response = axios.post(CONFIG.ADD_CITATION_URL,
            {
                token: window.localStorage.token,
                uuid,
                citation
            }, { headers: { 'authorization': `Bearer ${window.localStorage.token}` } })
            .catch(err => console.log(err))
    })

    function checkWordLen(val) {
        var len = val.split(/[\s]+/);
        console.log(len.length)
        if (len.length <= 40) { setCitation(val) }
        else {
            alert("You cannot put more than 40 words in this text area.");
            setCitation('')
            return false;
        }
        return true;
    }
    return (
        <div>
            <Popup trigger={<button className='btn btn-outline-info rounded-pill mt-4'> Certificate</button>} position="bottom center">
                <div>
                    <textarea value={citation} placeholder='Type something here! (max 40 words)'
                        style={{ borderRadius: "5px", height: "20vh", width: "48vh" }} onChange={e => checkWordLen(e.target.value)} />
                    {console.log(citation)}
                    <a href={`${CONFIG.F_CERTIFICATE_URL}?n=${uuid}`}
                        className=' btn btn-sm btn-outline-success rounded-pill m-2'>Generate Certificate</a>
                </div>
            </Popup>
        </div>
    )
}

export default CertificateBtn
