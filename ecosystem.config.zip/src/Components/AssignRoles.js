import React, { useEffect, useState } from 'react'
import Popup from 'reactjs-popup';
import axios from 'axios'
import { CONFIG } from '../config'
import { Form } from 'react-bootstrap';
import swal from "sweetalert2"
import Header from './Header'
import * as Icon from 'react-bootstrap-icons'
import DataTable from 'react-data-table-component'

const AssignRoles = () => {
    const roles = ['user', 'reviewer', 'approver', 'final approver', 'admin']
    const [users, setUsers] = useState([])
    const [newRole, setNewRole] = useState('')
    const [newUser, setNewUser] = useState({})
    useEffect(() => {
        axios.post(CONFIG.ALL_USERS_URL, {
            token: window.localStorage.token,
        })
            .then((response) => {
                setUsers(response.data.data)
            })
            .catch((err) => {
                console.log(err)
            })
    }, [])

    const handleNewUser =async (e) =>{
        e.preventDefault()
        const SDA_ACCESS_LEVEL = "Reader";
        const APP_KEY = "RR-APP-2b7e67ae-28b3-428b-acd0-fc2644930c3e";
        const NETWORK_USER = newUser.employeeID //new user qid
        const ROOT_USER = "u1138575";
        const SSO_REGISTRATION_URL = `https://dev2-sda.work.iqvia.com/sda-rest-api/api/external/entitlement/V1/ApplicationUsers?roleType=${SDA_ACCESS_LEVEL}&appKey=${APP_KEY}&userType=internal&networkId=${NETWORK_USER}&updatedBy=${ROOT_USER}`
        try {
            await axios.post(SSO_REGISTRATION_URL,
                {headers: 'Access-Control-Allow-Origin: *'} ).then(res => {
                if (res.status == 200) {
                    swal.fire({
                        title: 'Failure',
                        showDenyButton: false,
                        confirmButtonText: `Ok`,
                        text: res.status
                    })
                }
            })
        }
        catch (error) {
            swal.fire({
                title: 'Failure',
                showDenyButton: false,
                confirmButtonText: `Ok`,
                text: error
            })
        }
    }
    const assignRole = async (e, id) => {
        e.preventDefault()
        let resp = axios.post(CONFIG.CHANGE_ROLE_URL, {
            token: window.localStorage.token,
            id,
            role: newRole
        }, { headers: { 'authorization': `Bearer ${window.localStorage.token}` } })
            .then((response) => {
                window.location.reload()
            })
            .catch((err) => {
                console.log(err)
            })
    }
    const columns = [
        {
            name: 'Employee',
            selector: row => row.email,
            sortable: true,
        },
        {
            name: 'Current Role',
            selector: row => row.role,
            sortable: true,
        },
        {
            name: 'Assign New Role',
            selector: row =>
                <div className="row m-1">
                    <select className="form-select col" multiple="" aria-label="Default select example"
                        onChange={(e) => { setNewRole(e.target.value) }}>
                        <option value=''>Select one</option>
                        {roles.map(role => {
                            return (
                                <option key={role}>{role}</option>
                            )
                        })}
                    </select>
                    <button className="btn btn-outline-primary btn-sm col" onClick={(e) => assignRole(e, row._id)}>
                        <Icon.CheckCircleFill />
                        &nbsp;Update
                    </button>
                </div>
            ,
        }
    ]
    return (
        <div>
            <Header />
            <div className='container'>
                <div className="d-flex mx-auto">
                    <div className='col'>
                        <h4 className="title-section mt-5">Assign Roles to Employees</h4>
                        <div className="divider"></div>
                    </div>
                    <Popup trigger={<button className='btn btn-outline-info w-25 h-50 mt-5'> Add User</button>} position="bottom center">
                        <Form className='container' onSubmit={handleNewUser}>
                            <Form.Group className="mb-3" controlId="userid">
                                <Form.Label className="form-label">Employee ID:</Form.Label>
                                <Form.Control className="input-box" required type="text" placeholder=" Enter QID/UID"
                                    onChange={(e) => { setNewUser({ ...newUser, employeeID: e.target.value }) }}
                                     />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="accesslevel">
                                <Form.Label className="form-label">Employee Role:</Form.Label>
                                <Form.Control className="input-box" required type="text"  placeholder=" Enter role level"
                                    onChange={(e) => { setNewUser({ ...newUser, role: e.target.value }) }}
                                    />
                            </Form.Group>
                            <button className='btn btn-success'>Add</button>
                        </Form>
            </Popup>
            </div>
                <DataTable
                    columns={columns}
                    data={users}
                    pagination
                />
            </div>
        </div>
    )
}

export default AssignRoles
