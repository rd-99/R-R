import React from 'react'
import image from '../public/images/undraw_profile_re_4a55.svg'
import '../public/styles/Login.css'
import Axios from 'axios'
import { useState } from 'react'
import swal from 'sweetalert'
import { CONFIG } from '../config'

const Login = () => {

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const login = (e) => {
    e.preventDefault()
    Axios.post(`${CONFIG.LOGIN_URL}`, {
      email, password
    })
      .then((res) => {
        console.log("userRegister")
        if (res.data.success == true) {
          console.log(res.data)
          swal("Login Successful!", "Welcome to R&R!", "success")
          window.localStorage.setItem("token", res.data.token)
          window.localStorage.setItem("email", res.data.email)
          window.localStorage.setItem("role", res.data.role)
         if (res.data.role == "user" || res.data.role == "reviewer") {
            window.location.href = CONFIG.F_CATEGORY_URL
          } else window.location.href = CONFIG.F_DASHBOARD_URL
        }
      })
    console.log(e)
  }

  const loginSSO = (e) => {
    e.preventDefault();
    location.href = CONFIG.SSO_URL;
  }

  return (
    <div style={{ marginTop: "15vh" }}>
      <form className="form-signin">

        <div className="text-center mb-4">
          <img className="mb-4" src={image} alt="" width="50%" height="90" style={{ margin: "20px" }} />
          <h4 className=" mb-3 text-muted">Login to continue</h4>
        </div>

        <div className="form-floating mb-3">
          <input onChange={e => { setEmail(e.target.value) }} type="email" className="form-control" id="floatingInput" placeholder="name@example.com" />
          <label htmlFor="floatingInput">Email address</label>
        </div>

        <div className="form-floating mb-3">
          <input onChange={e => { setPassword(e.target.value) }} type="password" className="form-control" id="floatingPassword" placeholder="Password" />
          <label htmlFor="floatingPassword">Password</label>
        </div>

        <button className="mt-1 w-100 btn-primary" type="submit" onClick={login}>Sign in</button>
        <hr />
        <button className="mt-1 w-100 btn-secondary" type="submit" onClick={loginSSO}>SSO Login</button>
        <p className="mt-5 mb-3 text-muted text-center">&copy; IQVIA 2023</p>
      </form>
    </div>
  )
}

export default Login
