import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { CONFIG } from '../config';
import prize from '../public/images/prize.jfif'
import p2 from '../public/images/p2.jfif'
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';

const myCarousel = () => {
    const [winners, setWinners] = useState([])
    useEffect(() => {
        axios.post(CONFIG.WINNERS_URL, {
            token: window.localStorage.token,
        }).then((response) => {
            setWinners(response.data.data)
        }).catch((err) => {
            console.log(err)
        })
    }, [])
    return (
        <Carousel
        autoPlay={true}
        // interval={5000}
        // width={700}
        infiniteLoop
        stopOnHover={true}
        showThumbs={false}>
            {winners.map(nom => (
                    <div className='row' key={winners.indexOf(nom)}>
                        <img src={prize} className='col col-lg-4 col-4 mt-2 h-50 w-50'/>
                         {/* style={{ height: "50vh", width: "45vh" }} /> */}
                        <div className='col col-lg-6 col-sm-6 mt-4 h-50 '>
                            {/*  style={{ height: "50vh"}} */}
                    <center className="alert alert-info p-0 m-3">{nom.nomineeName}</center>
                            {/* <p className='text-info'>{nom.nomineeName}</p> */}
                           In <p className='text-info'>{nom.nominationCategory}:
                                </p>{nom.certificateCitation}
                        </div>
                    </div>
            ))}
        </Carousel>
    );
}

export default myCarousel