module.exports = {
  apps : [{
    name: "R&R FRONTEND UI - v1.0.0",
    script: "node_modules/react-scripts/scripts/start.js",
    env: {
      NODE_ENV: "development",
    },
    env_production: {
      NODE_ENV: "production",
    }
  }]
}
