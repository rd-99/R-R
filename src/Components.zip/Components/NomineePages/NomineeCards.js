import React, { useEffect, useState } from "react"
import axios from 'axios'
import ReactPaginate from 'react-paginate'
import { CONFIG } from "../../config"
import Header from "../Header"
import '../../public/styles/Card.css'
import { Col, Row, Container, Form } from "react-bootstrap"
import image1 from "../../public/images/useravatar"
import img1 from '../../public/images/undraw_taken_re_yn20.svg'
import { CardCategories } from "../Cards/CardCategories"
// const images = require.context('../../../../be/profileImages', true)

function Items({ currentItems }) {
  
  return (
    <Row xs={1} md={4} className="g-4">

      {currentItems &&
        currentItems.map((item) => (
          <div key={item.uuid} className="card" style={{ width: "18rem" }}>
            <div className="text-center" >
              {item.profileImg ?
                <img className="card-img-top mt-4 mb-2" src={`${CONFIG.VIEW_FILES}?display_img=${item?.uuid}_${item?.profileImg[0]}`}
                style={{ width: "100px", height: "100px" }} alt="Nomination Picture" /> :
                <img className="card-img-top mt-4 mb-2" src={image1} style={{ width: "100px", height: "100px" }}/>
              }
              <hr />
            </div>
            <div className="card-body text-center ">
              <h4 className="card-title mb-2">{item.nomineeName}</h4>
              <h6 className="text-muted">Nominated under:</h6>
              <p>{item.nominationCategory} </p>
              {item.statusOfNomination=='Winner' && 
              <h6 className="text-warning">Rating by Nivedita: {item.finalRating}/5</h6> 
              }
              {item.statusOfNomination == "Incomplete" ?
                <a href={`${CONFIG.F_FORM_URL}?cat=${item.nominationCategory}$u=${item.uuid}`} >Complete the form </a>
                : <p><a href={`${CONFIG.F_DETAILS_URL}?n=${item.uuid || ''}`}>View More</a></p>}
            </div>
          </div>
        ))}
    </Row>
  )
}

const NomineeCards = () => {
  const [nominees, setNominees] = useState([])
  var [searchDate, setSearchDate] = useState('')
  var [searchCategory, setsearchCategory] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  useEffect(() => {
    getNominee()
  }, [])

  

  const getNominee = async () => {

    let response = await axios
      .post(`${CONFIG.NOMINEES_URL}?type=${window.location.href.split('?')[1].split('=')[1]}`, {
        token: window.localStorage.token,
        reqType: window.location.href.split('?')[1].split('=')[1],
        nominatorEmail: window.localStorage.getItem("email"),
        role: window.localStorage.getItem("role")
      }, { headers: { 'authorization': `Bearer ${window.localStorage.token}`, 'email' : window.localStorage.getItem("email") }},
      )
      .then((response) => {
        setNominees(response.data.data)
        setIsLoading(false)
        let fetchnom = response.data.data
      })
      .catch((err) => {
        console.log(err)
      })
  }
  var data = nominees
  if (searchCategory != '') {
    const filteredData = data.filter(
      item => item.nominationCategory && item.nominationCategory.toLowerCase().includes(searchCategory.toLowerCase()),
    )
    data = filteredData
  }
  if (searchDate != '') {
    const dateRange = [
      {
        name: "Q1",
        startDate: new Date(`${new Date(Date.now()).getFullYear()}-01-01`).toISOString(),
        endDate: new Date(`${new Date(Date.now()).getFullYear()}-03-31`).toISOString()
      },
      {
        name: "Q2",
        startDate: new Date(`${new Date(Date.now()).getFullYear()}-04-01`).toISOString(),
        endDate: new Date(`${new Date(Date.now()).getFullYear()}-06-30`).toISOString()
      },
      {
        name: "Q3",
        startDate: new Date(`${new Date(Date.now()).getFullYear()}-07-01`).toISOString(),
        endDate: new Date(`${new Date(Date.now()).getFullYear()}-09-30`).toISOString()
      },
      {
        name: "Q4",
        startDate: new Date(`${new Date(Date.now()).getFullYear()}-10-01`).toISOString(),
        endDate: new Date(`${new Date(Date.now()).getFullYear()}-12-31`).toISOString()
      }
    ]
    var reqRange = dateRange.find(quarter => quarter.name == searchDate)
    reqRange ? data = data.filter(item =>
      item.createdOn >= reqRange.startDate && item.createdOn < reqRange.endDate) : data
  }

  const [itemOffset, setItemOffset] = useState(0)
  const itemsPerPage = 5
  console.log(`Loading items from ${itemOffset} to ${itemOffset + itemsPerPage}`)
  const currentItems = data.slice(itemOffset, itemOffset + itemsPerPage)
  const pageCount = Math.ceil(nominees.length / itemsPerPage)
  // Invoke when user click to request another page.
  const handlePageClick = (event) => {
    const newOffset = (event.selected * itemsPerPage) % nominees.length
    setItemOffset(newOffset)
  }
  const status = window.location.href.split('?')[1].split('=')[1]
  return (
    <div>
      <Header />
      <Container style={{ marginBlock: "50px" }}>
        <Col mb={5} >
          {/* page titles */}
          <div> {status == "Pending" &&
            <><h4 className="title-section">Review Nominations</h4>
              <div className="divider"></div></>
          }</div>
          <div> {status == "Winner" &&
            <><h4 className="title-section">Wall Of Fame</h4>
              <div className="divider"></div></>
          }</div>
          <div> {status == "Pending_Reviewer_Assignment" &&
            <><h4 className="title-section">Assign Reviewers</h4>
              <div className="divider"></div></>
          }</div>
          <div> {status == "Incomplete" &&
            <><h4 className="title-section">Forms Saved For later</h4>
              <div className="divider"></div></>
          }</div>
        </Col>

        {isLoading == true && <p className="text-muted"> Loading...</p>}
        {/* filters for category and quarters */}
        <div className="row w-75 mb-4">
          <Form.Select className="col w-100 m-2" style={{ borderRadius: "10px", width: "25px" }} onChange={(e) => { setSearchDate(e.target.value) }}>
            <option value={null}>Filter By Quarter</option>
            {['Q1', 'Q2', 'Q3', 'Q4', "View All"].map(item => (
              <option key={item}>{item}</option>
            ))}
          </Form.Select>
          <Form.Select className="col w-100 m-2" style={{ borderRadius: "10px", width: "25px" }} onChange={(e) => setsearchCategory(e.target.value)}>
            <option value={null}>Filter By Category</option>
            {CardCategories.map(item => (
              <option key={item.title} value={item.title}>{item.title}</option>
            ))}
            <option value=''>View All Nominations</option>
          </Form.Select>
        </div>
        {(currentItems.length <= 0 && isLoading == false) &&
          <div className='justify-content-center m-3' >
            <center>
              <img src={img1} style={{ width: "230px", height: "200px" }} />
              <h4>
                No data found or you don't have access to view the page
              </h4>
            </center>
          </div>
        }
        {currentItems.length > 0 && isLoading == false &&
          <>
            <Items currentItems={currentItems} />
            <ReactPaginate
              containerClassName={"pagination "}
              pageClassName={"page-item"}
              pageLinkClassName={"page-link"}
              breakLabel="..."
              nextLabel="Next >"
              onPageChange={handlePageClick}
              pageRangeDisplayed={5}
              pageCount={pageCount}
              previousLabel="< Previous"
              renderOnZeroPageCount={null}
            /></>
        }

      </Container>
    </div>
  )
}

export default NomineeCards


